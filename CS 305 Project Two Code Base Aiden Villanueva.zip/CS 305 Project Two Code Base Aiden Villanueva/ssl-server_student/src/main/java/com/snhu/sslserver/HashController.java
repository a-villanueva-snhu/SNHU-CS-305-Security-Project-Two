package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@RestController
public class HashController {

    // This method will be available at the endpoint: /hash
    @GetMapping("/hash")
    public String getHash(@RequestParam(defaultValue = "DefaultData") String data) {
        try {
            // 1. Get an instance of the SHA-256 MessageDigest
            MessageDigest digest = MessageDigest.getInstance("SHA-256");

            // 2. Hash the input data string (converted to bytes)
            byte[] encodedhash = digest.digest(data.getBytes(StandardCharsets.UTF_8));

            // 3. Convert the byte array into a hexadecimal string
            return bytesToHex(encodedhash);

        } catch (NoSuchAlgorithmException e) {
            // This error happens if the algorithm name (SHA-256) is wrong
            e.printStackTrace();
            return "Error: Hashing algorithm not found.";
        }
    }

    // Helper method to convert a byte array to a hex string
    private static String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder(2 * hash.length);
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }
}
